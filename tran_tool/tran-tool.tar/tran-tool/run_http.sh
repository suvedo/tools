#!/bin/bash
nohup python simplehttpserver.py 8089 >> http.log &
